package com.capgemini.trg.model;

public class Customer {
private Integer customerId;
private String name;
private String email;
private Long mobile;
public Customer()
{
	
}

public Customer(Integer customerId, String name, String email, Long mobile) {
	super();
	this.customerId = customerId;
	this.name = name;
	this.email = email;
	this.mobile = mobile;
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", name=" + name + ", email="
			+ email + ", mobile=" + mobile + "]";
}

public Integer getCustomerId() {
	return customerId;
}

public void setCustomerId(Integer customerId) {
	this.customerId = customerId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public Long getMobile() {
	return mobile;
}

public void setMobile(Long mobile) {
	this.mobile = mobile;
}


}
