package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.trg.model.Customer;

/**
 * Servlet implementation class JSTController
 */
@WebServlet("/JSTController")
public class JSTController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
  

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Integer index=Integer.parseInt(request.getParameter("index"));
		String url="";
		ServletContext context=request.getServletContext();
		context.setAttribute("company","capgemini");
		List<Customer> customerList=new ArrayList<Customer>();
		populateCustomerList(customerList);
		request.setAttribute("customerList",customerList);
		
		if(index==1)
			url="core/coreTags1.jsp";
		else if(index==2)
		{
			url="core/coreTags1.jsp";
		}
		else if(index==3)
		{
			url="core/coreTags1.jsp";
		}
		else if(index==4)
		{
			url="core/coreTags2.jsp";
		}
		else if(index==5)
		{
			url="core/coreTags2.jsp";
		}
		request.getRequestDispatcher(url).forward(request,response);
		
	}

	private void populateCustomerList(List<Customer> customerList) {
		// TODO Auto-generated method stub
		customerList.add(new Customer(100,"smith","smith@gmail.com",9553075484L));
		customerList.add(new Customer(101,"sm","sm@gmail.com",8553075484L));
		customerList.add(new Customer(102,"smit","smit@gmail.com",7553075484L));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}
