package com.cap.session.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cap.session.model.Customer;
import com.sun.istack.internal.logging.Logger;
@Repository
public class DaoImpl implements DaoInter {
	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public List<Customer> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		final Logger myLogger = Logger.getLogger(DaoImpl.class);			
		String sql="From ScheduledSessions";
		//EntityTransaction transaction=entityManager.getTransaction();
		//try {
			//transaction.begin();
			Query query=entityManager.createQuery(sql);
			List<Customer> customerList=query.getResultList();			
			//transaction.commit();
			//myLogger.info(AppConfig.PROPERTIES.getProperty("CUSTOMER_READALL.SUCCESS"));
			return customerList;
		/*}catch(PersistenceException e) {			
			myLogger.error(e.getMessage());		
			throw new CustomerException(e.getMessage());
		}catch(Exception e) {	
			myLogger.error(e.getMessage());
			throw new CustomerException(e.getMessage());
		}*/
		
	}

}
