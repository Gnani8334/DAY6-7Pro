package com.cap.session.dao;

import java.util.List;

import com.cap.session.model.Customer;



public interface DaoInter {
	public List<Customer> getAllCustomerDetails();
}
