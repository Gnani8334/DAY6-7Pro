package com.cap.session.service;

import java.util.List;

import com.cap.session.model.Customer;

public interface ServiceInter {
public List<Customer> getAllCustomerDetails();
}
