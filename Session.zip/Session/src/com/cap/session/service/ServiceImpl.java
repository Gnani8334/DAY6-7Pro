package com.cap.session.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.session.dao.DaoInter;
import com.cap.session.model.Customer;
@Service
public class ServiceImpl  implements ServiceInter{
	@Autowired
	private DaoInter customerDAO;
	@Override
	public List<Customer> getAllCustomerDetails() {
		List<Customer> customerList = null;
		// TODO Auto-generated method stub
		List<Customer> customerEntityList=customerDAO.getAllCustomerDetails();
		//System.out.println(customerEntityList.size());
		
		if(customerEntityList !=null) {				
			
			customerList = customerEntityList;
	}
		
		return customerList;

}
	}
