package com.cap.session.web;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cap.session.model.Customer;
import com.cap.session.service.ServiceInter;

@Controller
@RequestMapping(value="/session")
public class SessionController {
	@Autowired
	ServiceInter customerService;
	@RequestMapping(value="/sessions", method=RequestMethod.GET)
	public ModelAndView getAllCustomerDetails() {
		//try {
			List<Customer> customerList = customerService.getAllCustomerDetails();
			if(customerList.size()!=0) {				
				return new ModelAndView("ScheduledSessions","customerList",customerList);
			}else {
				return new ModelAndView("cust_status","message","No customers in database");
			}
	/*	}catch(CustomerException e) {
			e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}*/

}
}
